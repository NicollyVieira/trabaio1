var n1 = prompt("Digite o primeiro número inteiro")
n1=parseInt(n1);
var n2 = prompt("Digite o segundo número inteiro")
n2=parseInt(n2);

//var soma = n1+n2;
//var diferenca = n1-n2;//
//var produto = n1*n2;//
//var quociente = n1/n2;//

//document.write("A soma dos dois números é: ",soma);//
//document.write("<br>A diferença dos dois números é: ",diferenca);//
//document.write("<br>O produto dos dois números é: ",produto);//
//document.write("<br>O quociente dos dois números é: ",quociente);//

var potencia = Math.pow(n1,n2);
document.write("Elevando o ",n1," ao expoente ",n2," o resultado é ",potencia);