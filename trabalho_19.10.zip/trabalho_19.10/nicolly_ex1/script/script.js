//var raio= prompt("Digite o valor do raio");//
//var comprimento=2*Math.PI*raio;//
//var area=Math.PI*Math.pow(raio,2);//
//alert("O comprimento do circulo é: "+ comprimento +" e a área do circulo é: "+area);//

var raio= prompt("Digite o valor do raio");
raio= parseInt(raio);


var comprimento=2*Math.PI*raio;
comprimento= comprimento.toFixed(2);
var area=Math.PI*Math.pow(raio,2);
area = area.toFixed(2);

alert("O comprimento do circulo é: "+ comprimento +" e a área do circulo é: "+area);