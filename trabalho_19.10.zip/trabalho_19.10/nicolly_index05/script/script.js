var nome= prompt("Digite seu nome: ");
document.write("Olá, ",nome);

var idade=prompt("Digite sua idade");
alert("Sua idade é: " + idade);