type="text/javascript"
var n1 = prompt("Digite um número: ");
var n2 = prompt("Digite outro número: ");
document.write("A soma dos números é: ", parseInt(n1) + parseInt(n2));